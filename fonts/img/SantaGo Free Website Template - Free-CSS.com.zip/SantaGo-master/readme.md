<a href="http://creatrix.us/demo/santago/">
	<img src="https://d13yacurqjgara.cloudfront.net/users/149279/screenshots/1828193/santago-free_christmas_sales_and_affiliate_landing_page_template.jpg" alt="SantaGo - Free Christmas Sales and Affiliate HTML5 Landing Page Template">
</a>

SantaGo - Free Christmas Sales and Affiliate HTML5 Landing Page Template
-------------------
SantaGo is another free Bootstrap HTML Christmas sales and affiliate page template built and distributed by EvenFly Team as a small Cristmas gift under Creative Commons 3.0 license.

As long the codes already well commented, I don't think there's any additional help guide necessary. Even so, feel free to contact us through support@evenfly.com if you have any question/suggestion.

Live Demo: http://demo.evenfly.com/view?theme=SantaGo

View the post on Dribbble: https://dribbble.com/shots/1828193

If you like this template, you may like to see our other templates available here http://evenfly.com

Or follow us on

https://www.facebook.com/evenflyteam

https://twitter.com/EvenFlyTeam


License
-------------------
Creative Commons Attribution 3.0 Unported https://creativecommons.org/licenses/by/3.0/


Special Thanks!
-------------------
Christmas icons: https://dribbble.com/srizon/buckets/247589-SantaGo

Background Image: http://unsplash.com/

Animate.css: https://github.com/daneden/animate.css

Hasin Hyder: https://github.com/hasinhayder/StickySocialBar

Scott Schiller: https://github.com/scottschiller/Snowstorm

NiceScroll: https://github.com/inuyaksa/jquery.nicescroll

Matthieu Aussaguel: https://github.com/matthieua/WOW
